## Env Variables (EDIT THESE) ##
#ProfileUnity Server name (E.G. (Prou.server.domain))#
[string]$global:servername= "ProU Server Name"
#login for proU Console#
$user= "ProU User"
#Follow run Secure String instruction to make Password file. (path to password.txt)#
$pass=Get-Content c:\temp\Password.txt | ConvertTo-SecureString
#Save Path for Backup.zip#
[string]$global:savepath= "c:\temp\"

#####################################################################

##login Function

function connect-ProfileUnityServer{
##Ignore-SSL Library Code
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

##Get Creds
#[string]$global:servername= Read-Host -Prompt 'FQDN of ProfileUnity Server Name'

$pass2=[Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($pass))

#Connect to Server
Invoke-WebRequest https://"$servername":8000/authenticate -Body "username=$user&password=$pass2" -Method Post -SessionVariable session
$global:session=$session
}


## Download latest Backup
function Backup-Proulatest
{
##Start Backup
$PUBC= ((Invoke-WebRequest https://"$servername":8000//api/database/backup -WebSession $session).Content) | ConvertFrom-Json
##Pause for backup to complete
timeout /t 10 /nobreak
#getlist
$PUBL = ((Invoke-WebRequest https://"$servername":8000/api/database/backup/list -WebSession $session).Content) | ConvertFrom-Json
#Get latest Backup ID
$PUBID=$PUBL.tag | Foreach-Object {$_.Created = [DateTime]$_.Created; $_} | 
Group-Object Computer | 
Foreach-Object {$_.Group | Sort-Object Created | Select-Object -Last 1} | foreach {$_.Id}
#back it up
$pubfilename="ProU-Backup-" + "$PUBID" +".zip"
$backup=((Invoke-WebRequest https://"$servername":8000/api/database/backup/$PUBID -WebSession $session))
$savepath1="$savepath" + "$pubfilename"
$saveAttachment = [System.IO.File]::WriteAllBytes("$savepath1", $backup.content)
}

## Connect to ProfileUnity Server and backup database ##
connect-ProfileUnityServer
timeout /t 2 /nobreak
Backup-Proulatest
