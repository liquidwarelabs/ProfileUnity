<#
.SYNOPSIS
   Back up Profile Unity Database Script for scheduled task
.DESCRIPTION
   Back up Profile Unity Database Script for scheduled task
.NOTES
   Version:        1.0
   Author:         Ryan Butler (AHEAD)
   Creation Date:  01-21-2019
   Purpose/Change: Based on https://github.com/liquidwarelabs/ProfileUnity/tree/master/PowerTools/ProfileUnity%20Backup
.PARAMETER servername 
   Profile Unity server name
.PARAMETER User
   Profile Unity username
.PARAMETER Passfile
   Password file location
.PARAMETER SavePath
   Location to store backup files (NO trailing \)
.PARAMETER purgeold
   Purge old local backup file(s)
.PARAMETER keepcount
   How many local backups to keep
.EXAMPLE
   Runs backup of the profileunity database and keeps the 3 latest backups
   .\backupProUDB.ps1 -servername "myprouserver.domain.com" -passfile "C:\temp\mysecurepassword.txt" -savepath "c:\temp" -purgeold
#>
[cmdletbinding()]
Param
(
    [Parameter(Mandatory=$true)][string]$servername,
    [Parameter(Mandatory=$false)][string]$user="admin",
    [Parameter(Mandatory=$true)][string]$passfile,
    [Parameter(Mandatory=$true)][string]$savepath,
    [Parameter(Mandatory=$true)][switch]$purgeold,
    [Parameter(Mandatory=$false)]$keepcount = 3

)

#Checks for admin for SSL settings
If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
{

    Write-Warning "You do not have Administrator rights to run this script!`nPlease re-run this script as an Administrator!"
    Break
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}

#Checking for password file
if (Test-Path $passfile)
{
    Write-Host "Using $passfile"
}
else
{
    Write-Warning "Can't find password file. Please check path and try again"
    break
}


#Connect to Server
Write-Host "Connecting to $servername"
try {
    Invoke-RestMethod "https://$($servername):8000/authenticate" -Body "username=$user&password=$pass" -Method Post -SessionVariable session|Out-Null
}
catch {
    throw $_
}


#Start Backup
Write-Host "Starting backup"
try {
    Invoke-restmethod "https://$($servername):8000/api/database/backup" -WebSession $session -Method GET|Out-Null
}
catch {
    throw $_
}

#Get list of backups
$PUBL = Invoke-restmethod "https://$($servername):8000/api/database/backup/list" -WebSession $session
#Get newest backup ID
$PUBID = $publ.Tag|Sort-Object created -Descending|Select-Object -First 1

#Wait for latest backup to finish
if($PUBID.State -eq "Processing")
{
    do{
    write-host "Waiting for backup to complete..."
    Start-Sleep -Seconds 3
    #getlist
    $PUBL = Invoke-restmethod "https://$($servername):8000/api/database/backup/list" -WebSession $session
    #Get newest backup ID
    $PUBID = $publ.Tag|Sort-Object created -Descending|Select-Object -First 1
    }
    until($PUBID.State -eq "Success")

}

#Download backup
Write-Host "Downloading $($PUBID.Filename)"
try {
    Invoke-WebRequest "https://$($servername):8000/api/database/backup/$($PUBID.id)" -WebSession $session -OutFile "$savepath\$($PUBID.Filename)"|Out-Null
}
catch
{
    throw $_
}


#Purge previous backups
if($purgeold)
{
    #Check for local backup copy amounts 
    $localbackups = Get-ChildItem -Path $savepath -Filter "*.zip"

    if($localbackups.count -gt $backupcount)
    {
       write-host "Purging extra local backups"
       $localbackups|Sort-Object name -Descending|Select-Object -Last ($localbackups.Count - $backupcount)|Remove-Item -Force
    }


}
