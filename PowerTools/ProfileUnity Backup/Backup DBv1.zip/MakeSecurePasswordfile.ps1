$savepath=Read-Host "Password File Save location?" 
Read-Host "Enter Password" -AsSecureString |  ConvertFrom-SecureString | Out-File "$savepath\Password.txt"