<#
.SYNOPSIS
   Back up Profile Unity Database Script for scheduled task
.DESCRIPTION
   Back up Profile Unity Database Script for scheduled task
.NOTES
   Version:        4.0
   Author:         Ryan Butler (AHEAD)
   Update Author: Jack Smith (Liquidware)
   Creation Date:  01-21-2019
   Purpose/Change: Based on https://github.com/liquidwarelabs/ProfileUnity/tree/master/PowerTools/ProfileUnity%20Backup
.PARAMETER servername 
   Profile Unity server name
.PARAMETER User
   Profile Unity username
.PARAMETER passwordFileLocation
   Password file location
.PARAMETER ASEKeyFileLocation
   ASE file location
.PARAMETER SavePath
   Location to store backup files (Need trailing \)
.PARAMETER purgeold
   Purge old local backup file(s) (optional)
.PARAMETER backupcount
   How many local backups to keep (works with PurgeOld)
.EXAMPLE
   Runs backup of the profileunity database and keeps the 3 latest backups
   .\backupDBv4.ps1 -servername "ProUserver.domain.local" -user "administrator" -ASEKeyFileLocation "C:\temp\aeskey.txt" -passwordFileLocation "C:\temp\password.txt" -savepath "c:\temp\" -purgeold -backupcount 3
#>
[cmdletbinding()]
Param
(
    [Parameter(Mandatory=$true)][string]$servername,
    [Parameter(Mandatory=$false)][string]$user,
    [Parameter(Mandatory=$true)][string]$passwordFileLocation,
    [Parameter(Mandatory=$true)][string]$ASEKeyFileLocation,
    [Parameter(Mandatory=$true)][string]$savepath,
    [Parameter(Mandatory=$false)][switch]$purgeold,
    [Parameter(Mandatory=$false)]$backupcount

)

###########################################################################

#$pass=Get-Content $passwordFileLocation | ConvertTo-SecureString

#use key and password to create local secure password
$AESKey = Get-Content -Path $ASEKeyFileLocation
$pwdTxt = Get-Content -Path $passwordFileLocation
$securePass = $pwdTxt | ConvertTo-SecureString -Key $AESKey

## login Function ##

function connect-ProfileUnityServer{
##Ignore-SSL Library Code
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

##Get Creds
#[string]$global:servername= Read-Host -Prompt 'FQDN of ProfileUnity Server Name'

$pass2=[Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($securepass))

#Connect to Server
Write-host "Logging into ProfileUnity Server"
Invoke-WebRequest https://"$servername":8000/authenticate -Body "username=$user&password=$pass2" -Method Post -SessionVariable session
$global:session=$session
}

##########################

Connect-ProfileUnityServer
Start-Sleep -Seconds 2



#Start Backup
Write-Host "Starting backup"
try {
    Invoke-restmethod "https://$($servername):8000/api/database/backup" -WebSession $session -Method GET|Out-Null
}
catch {
    throw $_
}

#Get list of backups
$PUBL = Invoke-restmethod "https://$($servername):8000/api/database/backup/list" -WebSession $session
#Get newest backup ID
$PUBID = $publ.Tag|Sort-Object created -Descending|Select-Object -First 1

#Wait for latest backup to finish
if($PUBID.State -eq "Processing")
{
    do{
    write-host "Waiting for backup to complete..."
    Start-Sleep -Seconds 3
    #getlist
    $PUBL = Invoke-restmethod "https://$($servername):8000/api/database/backup/list" -WebSession $session
    #Get newest backup ID
    $PUBID = $publ.Tag|Sort-Object created -Descending|Select-Object -First 1
    }
    until($PUBID.State -eq "Success")

}

#Download backup
Write-Host "Downloading $($PUBID.Filename)"
try {
    Invoke-WebRequest "https://$($servername):8000/api/database/backup/$($PUBID.id)" -WebSession $session -OutFile "$savepath\$($PUBID.Filename)"|Out-Null
}
catch
{
    throw $_
}


#Purge previous backups
if($purgeold)
{
    #Check for local backup copy amounts 
    $localbackups = Get-ChildItem -Path $savepath -Filter "*.zip"

    if($localbackups.count -gt $backupcount)
    {
       write-host "Purging extra local backups"
       $localbackups|Sort-Object name -Descending|Select-Object -Last ($localbackups.Count - $backupcount)|Remove-Item -Force
    }


}
