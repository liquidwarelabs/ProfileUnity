ProfileUnity Database Backup Script
===================================

Overview
--------
This PowerShell script automates ProfileUnity database backups by connecting to the ProfileUnity server over HTTPS,
triggering a database backup via the REST API, waiting for it to complete, and downloading the resulting backup file.
It can optionally purge older local backups, keeping only the most recent files.

Audience: ProfileUnity Administrators
Tested With: ProfileUnity 6.8.7

Purpose
-------
Automates ProfileUnity database backups via API and optionally purges old backups.

How It Works
------------
+--------------------+       HTTPS/Port 8000        +------------------------+
| Backup Script      |---------------------------->| ProfileUnity Server     |
| (.ps1)             |                             | (API)                   |
|                    |<----------------------------|                        |
| 1. Reads AES Key   |                             |                        |
|    & Encrypted Pwd |                             |                        |
| 2. Authenticates   |                             |                        |
| 3. Starts Backup   |                             |                        |
| 4. Waits to Finish |                             |                        |
| 5. Downloads ZIP   |                             |                        |
| 6. Optionally Purge|                             |                        |
+--------------------+                             +------------------------+

Requirements
------------
- PowerShell: Current version of Windows PowerShell (5.1) or PowerShell 7.x
- ProfileUnity: Tested with 6.8.7 (ProfileUnity server must be reachable on port 8000)
- Network: No internet connection required
- SSL: Script includes a TrustAllCertsPolicy section to bypass certificate validation for environments using self-signed certificates
  Recommended: Use a valid SSL cert in production and remove the bypass.

Setup
-----
1. Generate Key and Encrypted Password
   Before using this script, you must have:
   - aeskey.bin — 256-bit AES key file (binary format)
   - password.enc — Encrypted password file

   These are created using the companion script:

       .\MakeSecurePasswordfile-AES.ps1

   That script will:
   - Prompt you for a ProfileUnity username/password
   - Generate the AES key and encrypted password
   - Save them as aeskey.bin and password.enc in the current directory

   Security Note: Protect the aeskey.bin file with NTFS ACLs so only authorized users can access it.

Usage
-----
Minimal Command:
    .\BackupDBv5.ps1 -ServerName "pu-server.domain.local" -User "administrator"

Full Command:
    .\BackupDBv5.ps1 -ServerName "pu-server.domain.local" `
                     -User "administrator" `
                     -PasswordFileLocation "C:\Keys\password.enc" `
                     -AESKeyFileLocation "C:\Keys\aeskey.bin" `
                     -SavePath "C:\Backups" `
                     -PurgeOld `
                     -BackupCount 3

Parameters
----------
| Parameter              | Required | Default Value                        | Description |
|------------------------|----------|---------------------------------------|-------------|
| ServerName             | Yes      | None                                  | FQDN of ProfileUnity server |
| User                   | Yes      | None                                  | Username for ProfileUnity authentication |
| PasswordFileLocation   | No       | .\password.enc                       | Path to encrypted password file |
| AESKeyFileLocation     | No       | .\aeskey.bin                         | Path to AES key file |
| SavePath               | No       | Current directory                     | Folder to save downloaded backups |
| PurgeOld               | No       | Disabled                              | If set, purges older backups after saving new one |
| BackupCount            | No       | 3                                     | Number of backups to retain when -PurgeOld is set |

Scheduling
----------
You can configure this script to run automatically using Windows Task Scheduler:
1. Open Task Scheduler → Create a new task.
2. Set the task to run as an account with access to the ProfileUnity server and backup folder.
3. Configure the Action:
       powershell.exe -ExecutionPolicy Bypass -File "C:\Scripts\BackupDBv5.ps1" -ServerName "pu-server.domain.local" -User "administrator" -PurgeOld -BackupCount 3
4. Set the Trigger to run at your desired backup frequency.

Security Considerations
-----------------------
- Keep aeskey.bin secured with NTFS permissions (accessible only by backup admin accounts).
- Store backups in a protected folder.
- If possible, use a trusted SSL certificate on the ProfileUnity server and remove the TrustAllCertsPolicy section.
- Do not email or store aeskey.bin in unsecured locations.

Troubleshooting
---------------
| Issue                                      | Cause                                                        | Solution |
|--------------------------------------------|--------------------------------------------------------------|----------|
| "Invalid URI: The hostname could not be..."| PowerShell interprets :8000 after a variable as scope notation| Use subexpression syntax: https://$($ServerName):8000/... |
| Authentication failed                      | Wrong username/password or mismatched password.enc           | Re-run MakeSecurePasswordfile-AES.ps1 to regenerate files |
| Cannot connect                              | Firewall or network block to port 8000                       | Verify connectivity and firewall rules |
| Backup stuck at "Processing"               | Large DB or slow disk on PU server                           | Increase wait loop or investigate PU performance |

Change Log
----------
- 5.0 — Updated to use default key/password file locations in script/current folder; new binary key format (aeskey.bin) and encrypted password file (password.enc); improved error handling, parameter defaults, and added full documentation.
