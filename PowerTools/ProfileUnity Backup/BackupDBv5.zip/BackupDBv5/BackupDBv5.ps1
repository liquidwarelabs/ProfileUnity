﻿<#
.SYNOPSIS
  Back up ProfileUnity database (scheduled-task friendly)

.DESCRIPTION
  Authenticates to a ProfileUnity server, triggers a DB backup,
  waits for completion, downloads the newest backup, and optionally
  purges older local backups.

.NOTES
  Version:        5.0
  Original Auth:  Ryan Butler (AHEAD)
  Updates:        Jack Smith (Liquidware), Greg Peck (Liquidware)
  Purpose/Change:
    - Default key/password file locations to the script/current folder
    - Use new filenames: aeskey.bin (raw bytes), password.enc (cipher text)
    - Add comments, sanity checks, and small bug fixes

.PARAMETER ServerName
  ProfileUnity server FQDN (no protocol, no port)

.PARAMETER User
  ProfileUnity username (required by the server’s auth API)

.PARAMETER PasswordFileLocation
  Path to encrypted password (default: .\password.enc)

.PARAMETER AESKeyFileLocation
  Path to AES key file (default: .\aeskey.bin)

.PARAMETER SavePath
  Folder to save downloaded backups (default: current/script folder)

.PARAMETER PurgeOld
  If set, old local backups are deleted after keeping -BackupCount most recent

.PARAMETER BackupCount
  How many local backups to keep when -PurgeOld is used
#>

[CmdletBinding()]
Param(
  [Parameter(Mandatory = $true)]
  [string]$ServerName,

  [Parameter(Mandatory = $true)]
  [string]$User,

  [Parameter(Mandatory = $false)]
  [string]$PasswordFileLocation,

  [Parameter(Mandatory = $false)]
  [string]$AESKeyFileLocation,

  [Parameter(Mandatory = $false)]
  [string]$SavePath,

  [Parameter(Mandatory = $false)]
  [switch]$PurgeOld,

  [Parameter(Mandatory = $false)]
  [int]$BackupCount = 3
)

# --- Resolve "here" (works in scripts & console)
$here = if ($PSScriptRoot) { $PSScriptRoot } else { $pwd.Path }

# --- Default file locations (new names)
if (-not $PasswordFileLocation) { $PasswordFileLocation = Join-Path $here 'password.enc' }
if (-not $AESKeyFileLocation)   { $AESKeyFileLocation   = Join-Path $here 'aeskey.bin'   }
if (-not $SavePath)             { $SavePath             = $here }

# --- Basic validation
if (-not (Test-Path $PasswordFileLocation)) {
  throw "Password file not found: $PasswordFileLocation"
}
if (-not (Test-Path $AESKeyFileLocation)) {
  throw "AES key file not found: $AESKeyFileLocation"
}
if (-not (Test-Path $SavePath)) {
  New-Item -ItemType Directory -Path $SavePath -Force | Out-Null
}

# --- Load key (raw bytes) and encrypted password (text) and rebuild SecureString
$keyBytes   = Get-Content -Path $AESKeyFileLocation -Encoding Byte
$cipherText = Get-Content -Path $PasswordFileLocation -Raw
$securePass = ConvertTo-SecureString -String $cipherText -Key $keyBytes

# --- Helper: ignore untrusted SSL certs (legacy PU appliances / lab use)
#     Prefer proper certs in production.
add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
  public bool CheckValidationResult(ServicePoint srvPoint, X509Certificate certificate, WebRequest request, int certificateProblem) {
    return true;
  }
}
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

# --- Convert SecureString to plain (only in-memory for the API call)
$plainPassPtr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePass)
try {
  $plainPass = [Runtime.InteropServices.Marshal]::PtrToStringAuto($plainPassPtr)
}
finally {
  if ($plainPassPtr -ne [IntPtr]::Zero) {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($plainPassPtr)
  }
}

# --- Authenticate and capture session
Write-Host "Logging into ProfileUnity server https://$ServerName:8000 ..."
try {
  # Legacy Windows PowerShell compatibility: -UseBasicParsing is optional
  Invoke-WebRequest "https://$ServerName:8000/authenticate" `
    -Body "username=$User&password=$plainPass" `
    -Method POST `
    -SessionVariable session | Out-Null
} catch {
  throw "Authentication failed: $($_.Exception.Message)"
}
$global:session = $session

# --- Start a backup
Write-Host "Starting backup..."
try {
  Invoke-RestMethod "https://$ServerName:8000/api/database/backup" `
    -WebSession $session -Method GET | Out-Null
} catch {
  throw "Failed to start backup: $($_.Exception.Message)"
}

# --- Poll until newest backup is 'Success'
Write-Host "Waiting for backup to complete..."
function Get-LatestBackup {
  $list = Invoke-RestMethod "https://$ServerName:8000/api/database/backup/list" -WebSession $session
  # API returns an object with Tag collection; sort by 'created' desc, take newest
  return ($list.Tag | Sort-Object -Property created -Descending | Select-Object -First 1)
}

$latest = Get-LatestBackup
while ($latest.State -eq 'Processing') {
  Start-Sleep -Seconds 3
  $latest = Get-LatestBackup
  Write-Host "  Status: $($latest.State)..."
}

if ($latest.State -ne 'Success') {
  throw "Latest backup did not complete successfully. State: $($latest.State)"
}

# --- Download the backup ZIP
$destFile = Join-Path $SavePath $latest.Filename
Write-Host "Downloading $($latest.Filename) to '$destFile'..."
try {
  Invoke-WebRequest "https://$ServerName:8000/api/database/backup/$($latest.id)" `
    -WebSession $session `
    -OutFile $destFile | Out-Null
} catch {
  throw "Failed to download backup: $($_.Exception.Message)"
}

# --- Optionally purge older local backups
if ($PurgeOld) {
  Write-Host "Purging older local backups, keeping $BackupCount most recent..."
  $localBackups = Get-ChildItem -Path $SavePath -Filter '*.zip' |
                  Sort-Object -Property LastWriteTime -Descending
  if ($localBackups.Count -gt $BackupCount) {
    $toDelete = $localBackups | Select-Object -Last ($localBackups.Count - $BackupCount)
    $toDelete | Remove-Item -Force
  }
}

Write-Host "Backup complete."
Write-Host "Saved to: $destFile"
