##login Functions Cert exceptions##

function connect-ProfileUnityServer{

########################################
# Adding certificate exception to prevent API errors
########################################
add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
public bool CheckValidationResult(
ServicePoint srvPoint, X509Certificate certificate,
WebRequest request, int certificateProblem) {
return true;
}
}
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
#optional security bypass
#[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'


##Prof
[string]$global:servername= Read-Host -Prompt 'FQDN of ProfileUnity Server Name'
$user = Read-Host "Enter Username"
$pass = Read-Host -assecurestring "Enter Password" 
$pass2=[Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($pass))

#Connect to Server
Invoke-WebRequest https://"$servername":8000/authenticate -Body "username=$user&password=$pass2" -Method Post -SessionVariable session
$global:session=$session
}
#########

## Get Filter ##
function Get-ProUFilters
{
$PUG = ((Invoke-WebRequest https://"$servername":8000/api/Filter -WebSession $session).Content) | ConvertFrom-Json
$PUG.Tag.Rows
}

##

## Edit ProfileUnity Filters ##
function Edit-ProUFilter([string]$name)
{
$PUG = ((Invoke-WebRequest https://"$servername":8000/api/Filter -WebSession $session).Content) | ConvertFrom-Json
[string]$ID=$PUG.Tag.Rows | Where-Object {$_.name -Match $name} | foreach-object {$_.id}
$configR= ((Invoke-WebRequest https://"$servername":8000/api/Filter/"$ID" -WebSession $session).Content) | ConvertFrom-Json
$config=$configR.tag
$global:CurrentFilter = $config
}

##
## get file function ##

Function Get-FileName($CSV)
{   
 [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") |
 Out-Null

 $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
 $OpenFileDialog.initialDirectory = $initialDirectory
 $OpenFileDialog.filter = "All files (*.*)| *.*"
 $OpenFileDialog.ShowDialog() | Out-Null
 $OpenFileDialog.filename
} 
## end function Get-FileName ##

## Connect to ProU Server ##

connect-ProfileUnityServer

## Get CSV Data ##
$ListCSVFile=Get-FileName
$lists=import-csv $ListCSVFile

## Add New Filter ##
Foreach ($item in $lists){
$FilterItem = get-proUfilters | where-object {$_.name -match $item.name}
if ($filterItem -EQ $null){
    
    write-host "Creating New Filter"
    #FilterRules Hashing ##
    $FilterRules=@{
    ConditionType=$item.FilterConditionType; 
    MatchType=$item.FilterMatchType; 
    Value=$item.Filtervalue; 
    TenantId=$item.TenantId;}
    $FilterRules=@($FilterRules)

##Make New FilterSettings ##
    $newFilter=[pscustomobject]@{
    Comments=$item.Comments;
    Connections=$item.Connections;
    FilterRules=$FilterRules;
    MachineClasses=$item.MachineClasses;
    Name=$item.Name;
    OperatingSystems=$item.OperatingSystems;
    RuleAggregate=$item.RuleAggregate;
    SystemEvents=$item.SystemEvents;
    TenantId=$item.TenantId;
}
    write-Host "Saving Filter"
    Invoke-WebRequest https://"$servername":8000/api/filter -ContentType "application/json" -Method Post -WebSession $session -Body($NewFilter | ConvertTo-Json -Depth 10) | out-null
}else{
    write-host "Editing Existing Filter"
    edit-proUfilter $item.name
    $FilterRulesADD=@{
        ConditionType=$item.FilterConditionType;
        MatchType=$item.FilterMatchType;
        Value=$item.Filtervalue;
        TenantId=$item.TenantId;}
    $FilterRulesADD=[pscustomobject]$FilterRulesADD
    $Currentfilter.FilterRules=$Currentfilter.FilterRules + $FilterRulesADD
    write-Host "Saving Filter Edit"
    Invoke-WebRequest https://"$servername":8000/api/filter -ContentType "application/json" -Method Post -WebSession $session -Body($CurrentFilter | ConvertTo-Json -Depth 10) | Out-Null
}

}